#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p logs
xelatex -interaction=nonstopmode -halt-on-error paper.tex 2>&1 | tee logs/latex-pass1.log
xelatex -interaction=nonstopmode -halt-on-error paper.tex 2>&1 | tee logs/latex-pass2.log
